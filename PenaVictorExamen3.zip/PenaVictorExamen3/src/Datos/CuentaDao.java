package Datos;

import domain.CuentasDTO;
import java.sql.SQLException;
import java.util.ArrayList;

public interface CuentaDao {

    //DTO = DATA TRANSFER OBJECT 
    public ArrayList<CuentasDTO> seleccionar() throws SQLException;

    public int insertar(CuentasDTO cuenta) throws SQLException;

    public int actualizar(CuentasDTO cuenta) throws SQLException;

//    public int eliminar(CuentasDTO persona) throws SQLException;
}
