package gestores;

import domain.CuentasDTO;
import java.util.*;

public class GestorCuentas {
public static ArrayList<CuentasDTO> hacienda = new ArrayList<CuentasDTO>();

//    private static Set<CuentasDTO> listaCuentas;
//
//    public static void iniciarListaCuentas() {
//        listaCuentas = new HashSet<CuentasDTO>();
//    }
//
//    public static boolean añadirCuentas(CuentasDTO cuenta) {
//        boolean comprobar = true;
//        listaCuentas.add(cuenta);
//        return false;
//    }
//    
//    public static Set<CuentasDTO> getListaCuentas() {
//        return listaCuentas;
//    }
//
//    public static void setListaCuentas(Set<CuentasDTO> listaCuentas) {
//        GestorCuentas.listaCuentas = listaCuentas;
//    }
}
